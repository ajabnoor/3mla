<?php

namespace App\Http\Controllers\Admin;

use Auth;
use App\Order;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class OrderController extends Controller
{
    public function index()
    {

        $orders = Order::with('product','status','buyer','owner')->has('messages')->get();
        // dd(Auth::user()->hasRole('admin'));
        return view('admin.orders.list', compact ('orders'));
    }

    public function show($id)
    {
        // dd(auth()->user()->hasRole('admin'));
        if (auth()->user()->hasRole('admin')){
            $order =  Order::where('id',$id)->with('product.currency','product.country','product.city','messages','status')->firstOrFail();
            return view('admin.orders.show', compact('order'));
        }
    }
}
