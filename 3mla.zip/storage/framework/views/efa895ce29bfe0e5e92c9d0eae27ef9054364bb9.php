<?php $__env->startSection('content'); ?>

<div class="row">
        <div class="col-md-6 col-md-offset-2">
            <div class="panel panel-default">
                <?php if($product->type === 'sell'): ?>
            <h2>عرض بيع <?php echo e($product->currency->name); ?></h2>
                
                <?php endif; ?>
                <div class="mx-auto" style="width: 100%;height:30px;">
                </div>
                <div class="panel-body">
                </div>
            </div>
        </div>
    </div>

    
    <div id="chat" class="row">
       <my-order></my-order>

        <div  class="col-sm-8">
            <div  class="card mb-4 box-shadow card-gray">
                <div class="card-body border-bottom2" style="max-height:65px">
                    <h4 class="card-title" ref="<?php echo e($product->id); ?>">تواصل مع البائع </h4>
                </div>
                <chat-log :messages="messages"></chat-log>

                <div class="card-body buttons-center " style="max-height:75px">
                    <chat-composer v-on:messagesent="addMessage" :orderid="orderid" :owner="owner"></chat-composer>
                </div>
    </div>
</div>
</div>
    <script>
    window.saleorderid = JSON.parse("<?php echo e(json_encode(null)); ?>");
    window.productid = JSON.parse("<?php echo e(json_encode($product->id)); ?>");
    window.newOrder = JSON.parse("<?php echo e(json_encode(true)); ?>");
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>