<?php $__env->startSection('content'); ?>

  <div class="row justify-content-md-right">
    <div class="col-md-auto">
      <h2>قائمة الطلبات</h2>
    </div>
    
    
  </div>


          <div class="table-responsive">
            <table class="table table-striped table-sm">
              <thead>
                <tr>
                    <th>المنتج</th>
                    <th>حالة الطلب</th>
                    <th>البائع</th>
                  <th>المشتري</th>
                  <th></th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                <td class="align-middle"><?php echo e($order->product->type); ?> <?php echo e($order->product->currency->code); ?></td>

                    <?php if($order->status['id'] == 0): ?>
                    <td class="align-middle">جديد</td>
                    <?php else: ?>
                    <td class="align-middle"><?php echo e($order->status['name']); ?></td>
                    <?php endif; ?>
                    <td class="align-middle"><?php echo e($order->owner->name); ?></td>
                  <td class="align-middle"><?php echo e($order->buyer->name); ?></td>
                  <td class="align-middle">
                      <a class="btn btn-warning btn-sm" href="<?php echo e(route('admin.order.show', $order->id)); ?>" role="button" style="float: left">دخول المحادثة</a>
                    </td>  
                      <td class="align-middle">
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
                
              </tbody>
            </table>
          </div>

  <style>
  
  .form-group {
    margin-bottom: 0rem;
}</style>

          <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>