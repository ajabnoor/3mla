<?php $__env->startComponent('mail::message'); ?>

<?php echo $__env->renderComponent(); ?>
