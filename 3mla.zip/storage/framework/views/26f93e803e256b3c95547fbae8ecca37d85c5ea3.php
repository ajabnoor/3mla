<?php $__env->startSection('content'); ?>

  <div class="row justify-content-md-right">
    <div class="col-md-auto">
      <h2>العملات</h2>
    </div>
    <div class="col-md-auto">
      <a href="<?php echo e(route('admin.pricecurrency.create')); ?>" class="btn btn-secondary btn-sm" role="button">إضافة عملة جديدة</a>
    </div>
    
  </div>


          <div class="table-responsive">
            <table class="table table-striped table-sm">
              <thead>
                <tr>
                  <th>العملة</th>
                  <th>الرمز</th>
                  <th></th>
                  <th></th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $pricecurrencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pricecurrency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                <td class="align-middle"><?php echo e($pricecurrency->name); ?></td>
                  <td class="align-middle"><?php echo e($pricecurrency->code); ?></td>
                <td></td>
                  <td class="align-middle">
                      
                      <a class="btn btn-warning btn-sm" href="<?php echo e(route('admin.pricecurrency.edit', $pricecurrency->id)); ?>" role="button" style="float: left">تعديل</a>
                    </td>  
                      <td class="align-middle">
                      <?php echo BootForm::open(['action' => ['Admin\PriceCurrencyController@destroy', $pricecurrency->id]]); ?>

                <?php echo BootForm::hidden('_method', 'DELETE'); ?>

                <?php echo Form::submit('حذف', ['class'=>'btn btn-danger btn-sm','onclick'=>'return confirm("هل أنت متأكد من حذف العملة؟")']); ?>

            <?php echo BootForm::close(); ?>

                  
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
                
              </tbody>
            </table>
          </div>



          <!-- Modal -->



  <style>
  
  .form-group {
    margin-bottom: 0rem;
}</style>

          <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>