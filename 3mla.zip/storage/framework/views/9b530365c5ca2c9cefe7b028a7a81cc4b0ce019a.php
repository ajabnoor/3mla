<tr>
    <td class="header">
        <a href="<?php echo e($url); ?>">
           موقع <?php echo e($slot); ?>

        </a>
    </td>
</tr>
