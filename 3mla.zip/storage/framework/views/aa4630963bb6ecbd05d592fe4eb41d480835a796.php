
       <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('img/logo.png')); ?>" alt="" style="height:50px;margin-left:10px"></a>

          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item active">
                <a class="nav-link" href="<?php echo e(route('home')); ?>">الرئيسية <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('user.myorders.index')); ?>">طلباتي
                    <?php if($buyer_notifications>0): ?>
                    <span class="badge badge-danger" ><?php echo e($buyer_notifications); ?></span>
                <?php endif; ?>
                </a>
                  
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="<?php echo e(route('user.mycustomers.index')); ?>">طلبات العملاء
                      <?php if($owner_notifications>0): ?>
                      <span class="badge badge-danger"><?php echo e($owner_notifications); ?></span>
                  <?php endif; ?>
                </a>
                </li>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('user.mysales.index')); ?>">مبيعاتي
              </a>
              </li>
              
              <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
              <li class="nav-item">
                  <a class="nav-link" href="<?php echo e(route('admin.home')); ?>">لوحة الأدمين</a>
                </li>
                <?php endif; ?>

                <li class="nav-item">
                    <a class="nav-link" href="https://twitter.com/3mla_net"> تويتر <img src="<?php echo e(asset('img/twitter.ico')); ?>" alt="" style="height:15px"></a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link" href="https://t.me/www_3mla_net"> تيليجرام <img src="<?php echo e(asset('img/telegram.png')); ?>" alt="" style="height:12px"></a>
                    </li>
                  
                  
              
            </ul>
          </div>
          <?php if(Route::has('login')): ?>
      
          <?php if(auth()->guard()->check()): ?>
          <a class="btn btn-outline-secondary droid" href="<?php echo e(route('logout')); ?>">تسجيل الخروج</a>
          <?php else: ?>
          <a class="btn btn-outline-secondary droid" href="<?php echo e(route('register')); ?>">تسجيل جديد</a>
          <a class="btn btn-outline-secondary droid btn-extra-margin" href="<?php echo e(route('login')); ?>">تسجيل دخول</a>
          <?php endif; ?>
      
    <?php endif; ?>
        </nav>
        