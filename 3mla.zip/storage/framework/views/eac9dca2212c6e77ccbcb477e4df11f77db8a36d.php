<?php $__env->startSection('content'); ?>

  <div class="row justify-content-md-right">
    <div class="col-md-auto">
      <h2>المنتجات</h2>
    </div>
    <div class="col-md-auto">
      <a href="<?php echo e(route('admin.product.create')); ?>" class="btn btn-secondary btn-sm" role="button">إضافة منتج جديدة</a>
    </div>
    
  </div>


          <div class="table-responsive">
            <table class="table table-striped table-sm">
              <thead>
                <tr>
                  <th>النوع</th>
                  <th>العملة</th>
                  <th>السعر</th>
                  <th>العملة النقدية</th>
                  <th>البلد</th>
                  <th>الحالة</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                <td class="align-middle"><?php echo e($product->type); ?></td>
                  <td class="align-middle"><?php echo e($product->currency->code); ?></td>
                  <td class="align-middle">
                    <?php if($product->price_type == 'marketwise'): ?>
                    حسب سعر السوق
                    <?php else: ?>
                    <?php echo e($product->price); ?>

                    <?php endif; ?>
                  </td>
                <td><?php echo e($product->price_currency->name); ?></td>
                  <td class="align-middle"><?php echo e($product->country->name); ?></td>
                  <td class="align-middle"><?php echo e($product->status); ?></td>
                  <td class="align-middle">
                      
                      <a class="btn btn-warning btn-sm" href="<?php echo e(route('admin.product.edit', $product->id)); ?>" role="button" style="float: left">تعديل</a>
                    </td>  
                      <td class="align-middle">
                      <?php echo BootForm::open(['action' => ['Admin\ProductController@destroy', $product->id]]); ?>

                      <?php echo BootForm::hidden('_method', 'DELETE'); ?>

                      <?php echo Form::submit('حذف', ['class'=>'btn btn-danger btn-sm','onclick'=>'return confirm("هل أنت متأكد من حذف المنتج؟")']); ?>

                      <?php echo BootForm::close(); ?>

                  
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
                
              </tbody>
            </table>
          </div>


  <style>
  
  .form-group {
    margin-bottom: 0rem;
}</style>

          <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>