<?php $__env->startComponent('mail::message'); ?>
# مرحبا بك <?php echo e($user->name); ?>

لديك تنبيه جديد على الطلب الخاص بعملة ال<?php echo e($product->currency->name); ?> <br>
لمتابعة الطلب قم بزيارة هذا الرابط<br>
<?php echo e($url); ?>



شكرا لك<br>
موقع <?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
