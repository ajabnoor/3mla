<?php $__env->startSection('content'); ?>

  <div class="row justify-content-md-right">
    <div class="col-md-auto">
      <h2>تعديل العملة</h2>
    </div>   
    
  </div>
  <div class="mx-auto" style="height: 20px;">
</div>
 
      
      

      
      <img src="<?php echo e(url('/')); ?>/storage/uploads/<?php echo e($currency->logo); ?>" alt="">



        <?php echo Form::model($currency, [
          'route' => ['admin.currency.update', $currency->id],
          'enctype'=>'multipart/form-data'
        ]); ?>

        <?php echo Form::bsText('name', 'إسم العملة'); ?>

        <?php echo Form::bsText('english', 'english'); ?>

        <?php echo Form::bsText('code', 'رمز العملة'); ?>

        <?php echo Form::bsText('wallet', 'رقم المحفظة'); ?>

        <?php echo Form::bsFile('logo_new', 'لوجو العملة'); ?>

        <?php echo Form::hidden('_method', 'PUT'); ?>

        <?php echo Form::hidden('logo'); ?>

        <?php echo Form::bsSubmit('تعديل'); ?>

        <?php echo Form::close(); ?>

    
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>