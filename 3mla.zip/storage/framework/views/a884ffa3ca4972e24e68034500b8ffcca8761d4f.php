<?php $__env->startSection('content'); ?>

<div class="row">
        <div class="col-md-6 col-md-offset-2">
            <div class="panel panel-default">
               
            <h2>تعديل المنتج</h2>

                <div class="mx-auto" style="width: 100%;height:30px;">
                </div>
                <div class="panel-body">
                    
                
                </div>
            </div>
        </div>
    </div>
   
    <div class="jumbotron  text-left " style="">
            <div id="app" class="row">
                    <div class=" col-md-8">
                    <?php echo Form::model($product, [
                        'route' => ['user.mysales.update', $product->id],
                      ]); ?>

                       <?php echo Form::bsSelect('type','نوع الطلب', ['buy'=>'شراء', 'sell'=>'بيع'] ); ?>

                       <?php echo Form::bsSelect('currency_id','العملة الرقمية', $currencies ,null, ['ref'=>'currency']); ?>

                       <div class="form-row">

                            <div class="form-group col-md-6" v-if="profit">
                            <?php echo e(Form::label('التسعير', null)); ?>

                            <?php echo e(Form::select('price_type', ['fixed'=>'ثابت', 'marketwise'=>'حسب سعر السوق'], $product->price_type, array_merge(['class' => 'form-control','ref'=>'profit', 'v-on:change'=>'showProfit']))); ?>

                            </div>
                            <div class="form-group col-md-12" v-else>
                             <?php echo e(Form::label('التسعير', null)); ?>

                             <?php echo e(Form::select('price_type', ['fixed'=>'ثابت', 'marketwise'=>'حسب سعر السوق'], $product->price_type, array_merge(['class' => 'form-control','ref'=>'profit', 'v-on:change'=>'showProfit']))); ?>

                             </div>
                            <div class="form-group col-md-6" v-show="profit">
                                <?php echo e(Form::label('نسبة (%) اضافية على سعر السوق', null)); ?>

                                <?php echo e(Form::text('profit',null, array_merge(['class' => 'form-control','placeholder'=>'أدخل رقم فقط','v-model'=>'percent','ref'=>'percent','v-on:input'=>'showProfit']))); ?>

                              </div>
                            </div>
                            
                              <div class="form-row">
               
                              <div class="form-group col-md-6" v-if="profit">
                                  <?php echo e(Form::label('سيتم تحديث السعر كل 10 دقائق', null)); ?>

                                  <?php echo e(Form::text('price',null, array_merge(['class' => 'form-control','placeholder'=>'أدخل السعر', 'v-model'=>'price' ,'disabled']))); ?>

                                </div>
                                <div class="form-group col-md-6" v-else>
                                  <?php echo e(Form::label('السعر', null)); ?>

                                  <?php echo e(Form::text('price',null, array_merge(['class' => 'form-control','placeholder'=>'أدخل السعر']))); ?>

                                </div>
                              <div class="form-group col-md-6">
                                  <?php echo e(Form::label('العملة النقدية', null)); ?>

                                  <?php echo e(Form::select('price_currency_id',$pricecurrencies ,null, array_merge(['class' => 'form-control', 'ref'=>'price_currency', 'v-on:change'=>'showProfit']))); ?>

                                  </div>
                        </div>
                           <?php echo Form::bsSelect('country_id','الدولة', $countries ,null, ['ref'=>'country', 'v-on:change'=>'showCities', 'id'=>'country']); ?>

                          
                           <div class="form-group">
                           <label for="اختر المدينة" class="control-label">المدينة</label>
                           <select class="form-control" name="city_id"> 
                           <option v-for="city in cities" v-bind:value="city.id">{{city.name}}</option>
                           </select>
                           </div>
           
           
                     <?php echo Form::bsText('transfer_methods', 'طرق التحويل'); ?>

                     <?php echo Form::bsText('speed', 'سرعة العملية'); ?>

                     <?php echo Form::bsText('available', 'الكمية المتاحة للبيع'); ?>

                     <?php echo Form::bsText('min_amount', 'الحد الأدنى للتحويل'); ?>

                     <?php echo Form::hidden('_method', 'PUT'); ?>

                     <?php echo Form::bsSubmit('تعديل'); ?>

                       <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
          <style>
                .jumbotron {
                    margin-bottom: 1rem;
                    padding: 2rem 2rem;
                }</style>
                <script>
                        window.globalpercent = JSON.parse("<?php echo e(json_encode($product->profit)); ?>");
                        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>