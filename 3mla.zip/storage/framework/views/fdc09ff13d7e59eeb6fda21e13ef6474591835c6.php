<?php echo e(Form::button($value,['class' => 'btn btn-primary'], $attributes)); ?>

