<div class="form-group">
        
    <?php echo e(Form::label('اختر ملف', null,['class'=>'col-md-4 col-form-label'] )); ?>

    <?php echo e(Form::file($name, ['class' => 'form-control filestyle'])); ?>

    
</div>