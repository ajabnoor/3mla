<?php $__env->startSection('title','قائمة طلباتي'); ?>
<?php $__env->startSection('description','قائمة طلباتي'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
        <div class="col-md-6 col-md-offset-2">
            <div class="panel panel-default">
            <h2>قائمة طلباتي</h2>

                <div class="mx-auto" style="width: 100%;height:30px;">
                </div>
                
                    <div class="panel-body">
                        
                    
                    </div>
                </div>
            </div>
        </div>
        <?php if(count($orders)): ?>
        <div class="row">
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-4">
                                <li class="list-group-item d-flex justify-content-between align-items-center darker">تاريخ الطلب<span class="badge badge-success"><?php echo e(\Carbon\Carbon::parse($order->messages->first()->created_at)->diffForHumans()); ?></span></li> 
                            <div class="card mb-4 box-shadow card-gray">
                                <img src="<?php echo e($order->product->currency->logo); ?> " alt="<?php echo e($order->product->currency->name); ?>" class="card-img-top-sm">
                                <div class="card-body padding-top-zero">
                                    <?php if( $order->product->type == 'buy'): ?>
                                    <h5 class="card-title sell-green">طلب <?php echo e($order->product->currency->name); ?> بسعر</h5>
                                    <h1 class="card-title pricing-card-title title-center"><?php echo e($order->product->price); ?> <?php echo e($order->product->price_currency->name); ?></h1>
                                    <?php elseif( $order->product->type == 'sell'): ?>
                                    <h5 class="card-title sell-red"><?php echo e($order->product->currency->name); ?> للبيع بسعر</h5>
                                    <h1 class="card-title pricing-card-title title-center"><?php echo e($order->product->price); ?> <?php echo e($order->product->price_currency->name); ?></h1>
                                    <?php endif; ?>
                                    </div> 
                                        <ul class="list-group list-group-flush">
                                                <li class="list-group-item d-flex justify-content-between align-items-center list-coin">الكمية المطلوبة<span class="badge badge-secondary">
                                                    <?php if($order->ordered_amount == 0): ?>
                                                    لم تحدد
                                                    <?php else: ?>
                                                    <?php echo e($order->ordered_amount); ?> <?php echo e($order->product->currency->code); ?>

                                                    <?php endif; ?>
                                                </span></li> 
                                                <li class="list-group-item d-flex justify-content-between align-items-center list-coin">
                                                    حالة الطلب
                                                        <?php if($order->status_id == 0): ?>
                                                        <span class="badge badge-secondary">جديد</span>
                                                        <?php else: ?>
                                                        <span class="badge badge-secondary"><?php echo e($order->status->name); ?></span>
                                                        <?php endif; ?>
                                                    </li> 
                                            <li class="list-group-item d-flex justify-content-between align-items-center list-coin">تنبيهات
                                                <?php if($order->buyer_notifications === 0): ?>
                                                <span class="badge badge-secondary">لا يوجد</span>
                                                <?php else: ?>
                                                <span class="badge badge-danger"><?php echo e($order->buyer_notifications); ?></span>
                                                <?php endif; ?>
                                            </li> 
                                        </ul> 
                                        <div class="card-body buttons-center">
                                            <a href="<?php echo e(route('user.myorders.edit', $order->id)); ?>" class="btn btn-success btn-sm ">متابعة الطلب</a> 
                                        </div>
                                    </div>
                                </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php else: ?>
                            <div class="jumbotron jumbotron-fluid text-center text-muted">
                                    <div class="container">
                                      <h1 class="display-6">لا يوجد لديك طلبات</h1>
                                    </div>
                                  </div>
                              <?php endif; ?>
                    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>