<?php $__env->startSection('content'); ?>

  <div class="row justify-content-md-right">
    <div class="col-md-auto">
      <h2>تعديل العملة</h2>
    </div>   
    
  </div>
  <div class="mx-auto" style="height: 20px;">
</div>
 
     <div class="row col-md-8">
        <?php echo Form::model($pricecurrency, [
          'route' => ['admin.pricecurrency.update', $pricecurrency->id],
          'enctype'=>'multipart/form-data'
        ]); ?>

        <?php echo Form::bsText('name', 'إسم العملة'); ?>

        <?php echo Form::bsText('code', 'رمز العملة'); ?>

        <?php echo Form::bsText('rate', 'التحويل للدولار'); ?>

        <?php echo Form::hidden('_method', 'PUT'); ?>

        <?php echo Form::hidden('logo'); ?>

        <?php echo Form::bsSubmit('تعديل'); ?>

        <?php echo Form::close(); ?>

      </div>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>