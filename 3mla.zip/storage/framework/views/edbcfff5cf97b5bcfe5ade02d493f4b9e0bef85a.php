<?php $__env->startSection('content'); ?>

  <div class="row justify-content-md-right">
    <div class="col-md-auto">
      <h2>إضافة منتج جديدة</h2>
    </div>   
    
  </div>
  <div class="mx-auto" style="height: 20px;">
</div>
 
<div id="app" class="row">
  <div class=" col-md-8">
            <?php echo Form::open(['action' => 'Admin\ProductController@store']); ?>

            <?php echo Form::bsSelect('type','نوع الطلب', ['buy'=>'شراء', 'sell'=>'بيع'] ); ?>

            <?php echo Form::bsSelect('user_id','العضو', $users ); ?>

            <?php echo Form::bsSelect('currency_id','العملة الرقمية', $currencies ,null, ['ref'=>'currency']); ?>

            <div class="form-row">

                <div class="form-group col-md-6" v-if="profit">
                <?php echo e(Form::label('التسعير', null)); ?>

                <?php echo e(Form::select('price_type', ['fixed'=>'ثابت', 'marketwise'=>'حسب سعر السوق'], 'اختر', array_merge(['class' => 'form-control','ref'=>'profit', 'v-on:change'=>'showProfit']))); ?>

                </div>
                <div class="form-group col-md-12" v-else>
                    <?php echo e(Form::label('التسعير', null)); ?>

                    <?php echo e(Form::select('price_type', ['fixed'=>'ثابت', 'marketwise'=>'حسب سعر السوق'], 'اختر', array_merge(['class' => 'form-control','ref'=>'profit', 'v-on:change'=>'showProfit']))); ?>

                    </div>
                <div class="form-group col-md-6" v-show="profit">
                    <?php echo e(Form::label('نسبة (%) اضافية على سعر السوق', null)); ?>

                    <?php echo e(Form::text('profit',null, array_merge(['class' => 'form-control','placeholder'=>'أدخل رقم فقط','v-model'=>'percent','ref'=>'percent','v-on:input'=>'showProfit']))); ?>

                  </div>
                </div>

                  <div class="form-row">

                  <div class="form-group col-md-6" v-if="profit">
                      <?php echo e(Form::label('سيتم تحديث السعر كل 10 دقائق', null)); ?>

                      <?php echo e(Form::text('price',null, array_merge(['class' => 'form-control','placeholder'=>'أدخل السعر', 'v-model'=>'price' ,'disabled']))); ?>

                    </div>
                    <div class="form-group col-md-6" v-else>
                      <?php echo e(Form::label('السعر', null)); ?>

                      <?php echo e(Form::text('price',null, array_merge(['class' => 'form-control','placeholder'=>'أدخل السعر']))); ?>

                    </div>
                  <div class="form-group col-md-6">
                      <?php echo e(Form::label('العملة النقدية', null)); ?>

                      <?php echo e(Form::select('price_currency_id',$pricecurrencies ,null, array_merge(['class' => 'form-control', 'ref'=>'price_currency', 'v-on:change'=>'showProfit']))); ?>

                      </div>
            </div>
                <?php echo Form::bsSelect('country_id','الدولة', $countries ,null, ['ref'=>'country', 'v-on:change'=>'showCities', 'id'=>'country']); ?>

               
                <div class="form-group">
                <label for="اختر المدينة" class="control-label">المدينة</label>
                <select class="form-control" name="city_id"> 
                <option v-for="city in cities" v-bind:value="city.id">{{city.name}}</option>
                </select>
                </div>


          <?php echo Form::bsText('transfer_methods', 'طرق التحويل'); ?>

          <?php echo Form::bsText('speed', 'سرعة العملية'); ?>

          <?php echo Form::bsText('available', 'الكمية المتاحة للبيع'); ?>

          <?php echo Form::bsText('min_amount', 'الحد الأدنى للتحويل'); ?>

          <?php echo Form::bsSelect('status','حالة الطلب', ['pending'=>'pending','published'=>'published','deleted'=>'deleted'] ); ?>


                <?php echo Form::bsSubmit('إضافة'); ?>

            <?php echo Form::close(); ?>

      
          </div>
          </div>   
        
          <script>
              window.globalpercent = JSON.parse("<?php echo e(json_encode(null)); ?>");
              </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>