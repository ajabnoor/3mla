<?php $__env->startSection('title','سوق بيع وشراء العملات الرقيمة والكريبتو والبيتكوين'); ?>
<?php $__env->startSection('description','موقع عملة هو سوق الكتروني آمن لبيع وشراء العملات الرقمية (الكريبتو) البيتكوين والإيثيرويم والبيتكوين كاش في العالم العربي.'); ?>
    
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc.intro', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
<div class="container" id="frontend" style="padding:0">
    <products-filter v-on:changed="filterProducts"></products-filter>
    <product :products="products"></product>
</div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>