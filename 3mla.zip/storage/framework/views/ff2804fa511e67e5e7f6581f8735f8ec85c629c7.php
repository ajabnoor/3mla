<?php $__env->startSection('content'); ?>

  <div class="row justify-content-md-right">
    <div class="col-md-auto">
      <h2>الدول</h2>
    </div>
    <div class="col-md-auto">
      <a href="<?php echo e(route('admin.country.create')); ?>" class="btn btn-secondary btn-sm" role="button">إضافة دولة جديدة</a>
    </div>
    
  </div>


          <div class="table-responsive">
            <table class="table table-striped table-sm">
              <thead>
                <tr>
                  <th>الدولة</th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                <td class="align-middle"><?php echo e($country->name); ?></td>
                  <td class="align-middle"></td>
                <td></td>
                  <td class="align-middle">
                      
                      <a class="btn btn-warning btn-sm" href="<?php echo e(route('admin.country.edit', $country->id)); ?>" role="button" style="float: left">تعديل</a>
                    </td>  
                      <td class="align-middle">
                      <?php echo BootForm::open(['action' => ['Admin\CountryController@destroy', $country->id]]); ?>

                      <?php echo BootForm::hidden('_method', 'DELETE'); ?>

                      <?php echo Form::submit('حذف', ['class'=>'btn btn-danger btn-sm','onclick'=>'return confirm("هل أنت متأكد من حذف العملة؟")']); ?>

                      <?php echo BootForm::close(); ?>

                  
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
                
              </tbody>
            </table>
          </div>


  <style>
  
  .form-group {
    margin-bottom: 0rem;
}</style>

          <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>