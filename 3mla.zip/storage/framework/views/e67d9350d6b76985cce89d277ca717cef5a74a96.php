    
<?php echo e(Form::submit($value,['class' => 'btn btn-primary'], $attributes)); ?>

