<?php $__env->startSection('content'); ?>

<div class="row">
        <div class="col-md-6 col-md-offset-2">
            <div class="panel panel-default">
                <h2>إضافة طلب جديد</h2>
                <div class="mx-auto" style="width: 100%;height:30px;">
                </div>
                <div class="panel-body">
                    
                <?php echo Form::open(['action'=>'OrdersController@store', 'method'=>'POST']); ?>

                <?php echo e(Form::bsSelect('نوع الطلب' , ['sell'=>'بيع', 'buy'=> 'شراء'])); ?>

                <?php echo e(Form::bsText('first_name')); ?>


                <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>