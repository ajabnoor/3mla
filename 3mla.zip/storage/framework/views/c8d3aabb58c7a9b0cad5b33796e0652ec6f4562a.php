<?php $__env->startSection('content'); ?>

  <div class="row justify-content-md-right">
    <div class="col-md-auto">
      <h2>إضافة عملة جديدة</h2>
    </div>   
    
  </div>
  <div class="mx-auto" style="height: 20px;">
</div>
 
<div class="row col-md-8">
  
            <?php echo Form::open(['action' => 'Admin\PriceCurrencyController@store', 'enctype'=>'multipart/form-data']); ?>

            <?php echo Form::bsText('name', 'إسم العملة'); ?>

            <?php echo Form::bsText('code', 'رمز العملة'); ?>

                <?php echo Form::bsSubmit('إضافة'); ?>

            <?php echo Form::close(); ?>

    
          </div>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>