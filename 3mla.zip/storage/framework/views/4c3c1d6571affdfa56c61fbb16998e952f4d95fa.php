<?php $__env->startSection('content'); ?>

<div class="row">
        <div class="col-md-6 col-md-offset-2">
            <div class="panel panel-default">
                <?php if($product->type === 'sell'): ?>
            <h2>عرض بيع <?php echo e($product->currency->name); ?></h2>
                

                <?php endif; ?>
                <div class="mx-auto" style="width: 100%;height:30px;">
                </div>
                <div class="panel-body">
                    
                
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-4">
            <div class="card mb-4 box-shadow card-gray">
                <img src="<?php echo e($product->currency->logo); ?> " alt="<?php echo e($product->currency->name); ?>" class="card-img-top">
                <div class="card-body padding-top-zero">
                    
                    <h1 class="card-title pricing-card-title title-center"><?php echo e($product->price); ?> 
                        <small class="text-muted">/ <?php echo e($product->currency->code); ?></small></h1></div> 
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item d-flex justify-content-between align-items-center list-coin">اسم العضو<span class="badge badge-info"><?php echo e($product->user->name); ?></span></li> 
                            <li class="list-group-item d-flex justify-content-between align-items-center list-coin">المكان<span class="badge badge-secondary"><?php echo e($product->country->name); ?> - <?php echo e($product->city->name); ?></span></li> 
                            <li class="list-group-item d-flex justify-content-between align-items-center list-coin">عمليات سابقة<span class="badge badge-secondary">14</span></li> 
                            <li class="list-group-item d-flex justify-content-between align-items-center list-coin">سرعة التحويل<span class="badge badge-secondary"><?php echo e($product->speed); ?></span></li> 
                            <li class="list-group-item d-flex justify-content-between align-items-center list-coin">طرق التحويل<span class="badge badge-secondary"><?php echo e($product->transfer_methods); ?></span></li> 
                            <li class="list-group-item d-flex justify-content-between align-items-center list-coin">الكمية المتوفرة<span class="badge badge-secondary"><?php echo e($product->available); ?> <?php echo e($product->currency->code); ?></span></li> 
                            <li class="list-group-item d-flex justify-content-between align-items-center list-coin">أقل كمية للبيع<span class="badge badge-secondary"><?php echo e($product->min_amount); ?></span></li> 
                            <li class="list-group-item d-flex justify-content-between align-items-center list-coin">التقييم<span class="badge badge-gold">بائع معتمد</span></li>
                        </ul> 
                        
                    </div>
                </div>

        <div  class="col-sm-8">
            <div class="card mb-4 box-shadow card-gray" >
                <div class="card-body border-bottom2" style="max-height:65px">
                    <h4 class="card-title">تواصل مع البائع </h4>
                </div>
                <chat-log :messages="messages"></chat-log>

                <div class="card-body buttons-center " style="max-height:75px">
                    <chat-composer v-on:messagesent="addMessage" :orderid="orderid" :owner="owner"></chat-composer>
                </div>
    </div>
</div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>