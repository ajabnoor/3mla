<?php $__env->startSection('content'); ?>

  <div class="row justify-content-md-right">
    <div class="col-md-auto">
      <h2>تعديل المدينة</h2>
    </div>   
    
  </div>
  <div class="mx-auto" style="height: 20px;">
</div>
 
     

        <?php echo Form::model($city, [
          'route' => ['admin.city.update', $city->id],
          'enctype'=>'multipart/form-data'
        ]); ?>

        <?php echo Form::bsSelect('country','اختر الدولة', $countries ); ?>

        <?php echo Form::bsText('name', 'إسم المدينة'); ?>

        <?php echo Form::hidden('_method', 'PUT'); ?>

        <?php echo Form::bsSubmit('تعديل'); ?>

        <?php echo Form::close(); ?>


        
    
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>