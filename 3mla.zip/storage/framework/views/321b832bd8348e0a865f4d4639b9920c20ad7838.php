<div class="form-group">
    <?php echo e(Form::label($label, null)); ?>

    <?php echo e(Form::select($name, $value, $default, array_merge(['class' => 'form-control'], $attributes))); ?>

</div>