
<div class="jumbotron">
    <img src="<?php echo e(asset('img/logo.png')); ?>" >
  <p class="lead">موقع عملة هو سوق الكتروني آمن لبيع وشراء العملات الرقمية (الكريبتو) البيتكوين والإيثيرويم والبيتكوين كاش في العالم العربي.</p>
  <hr class="my-4">
  <p>للاستفسارات ولمعرفة المزيد عن كيفية استخدام السوق تواصل معنا على قناتنا على <a href="https://t.me/www_3mla_net">التيليجرام <img src="<?php echo e(asset('img/telegram.png')); ?>" alt="" style="height:12px"></a></p>

</div>
<style>
.jumbotron {
    margin-bottom: 1rem;
    padding: 2rem 2rem;
}</style>