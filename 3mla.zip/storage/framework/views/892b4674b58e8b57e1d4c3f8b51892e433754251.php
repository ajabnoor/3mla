<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title>عملة | <?php echo $__env->yieldContent('title'); ?></title>
        <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>">
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet" type="text/css" >
        <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet" type="text/css" >
</head>
<body>
<?php echo $__env->make('inc.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="container">
            <?php echo $__env->make('inc.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('inc.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</div>
<script src="<?php echo e(url('/')); ?>/js/app.js"></script>

</body>
</html>