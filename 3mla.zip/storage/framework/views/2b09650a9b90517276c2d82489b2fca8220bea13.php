<?php $__env->startSection('content'); ?>

  <div class="row justify-content-md-right">
    <div class="col-md-auto">
      <h2>تعديل الدولة</h2>
    </div>   
    
  </div>
  <div class="mx-auto" style="height: 20px;">
</div>
 
     

        <?php echo Form::model($country, [
          'route' => ['admin.country.update', $country->id],
          'enctype'=>'multipart/form-data'
        ]); ?>

        <?php echo Form::bsText('name', 'إسم الدولة'); ?>

        <?php echo Form::hidden('_method', 'PUT'); ?>

        <?php echo Form::bsSubmit('تعديل'); ?>

        <?php echo Form::close(); ?>

    
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>