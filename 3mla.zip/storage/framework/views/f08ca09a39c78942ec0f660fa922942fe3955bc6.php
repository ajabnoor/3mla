<div class="form-group">
    <?php echo e(Form::label($label, null)); ?>

    <?php echo e(Form::text($name, $value, array_merge(['class' => 'form-control'], $attributes))); ?>

</div>