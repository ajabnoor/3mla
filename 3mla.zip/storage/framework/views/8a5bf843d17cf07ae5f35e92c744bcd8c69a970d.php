<?php $__env->startSection('content'); ?>

  <div class="row justify-content-md-right">
    <div class="col-md-auto">
      <h2>إضافة حالة طلب جديدة</h2>
    </div>   
    
  </div>
  <div class="mx-auto" style="height: 20px;">
</div>
 

            <?php echo Form::open(['action' => 'Admin\StatusController@store', 'enctype'=>'multipart/form-data']); ?>

            <?php echo Form::bsText('order', 'الترتيب'); ?>

            <?php echo Form::bsText('name', 'إسم الحالة'); ?>

            <?php echo Form::bsText('question', 'سؤال الحالة'); ?>

            <?php echo Form::bsSelect('user_type','صاحب الحالة', ['buyer'=>'المشتري', 'owner'=>'المالك'] ); ?>

            <?php echo Form::bsSubmit('إضافة'); ?>

            <?php echo Form::close(); ?>

    
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>