<?php $__env->startSection('content'); ?>
<div class="row">
        <div class="col-md-6 col-md-offset-2">
            <div class="panel panel-default">
            <h2>صفحة طلباتي</h2>

                <div class="mx-auto" style="width: 100%;height:30px;">
                </div>
                
                    <div class="panel-body">
                        
                    
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(count($order->messages)): ?>
                        <div class="col-sm-4">
                            <div class="card mb-4 box-shadow card-gray">
                                <img src="<?php echo e($order->product->currency->logo); ?> " alt="<?php echo e($order->product->currency->name); ?>" class="card-img-top">
                                <div class="card-body padding-top-zero">
                                    
                                    <h1 class="card-title pricing-card-title title-center"><?php echo e($order->product->price); ?> 
                                        <large class="text-muted">/ <?php echo e($order->product->currency->code); ?></small></h1>
                                    </div> 
                                        <ul class="list-group list-group-flush">
                                                <li class="list-group-item d-flex justify-content-between align-items-center darker">تاريخ الطلب<span class="badge badge-warning"><?php echo e(\Carbon\Carbon::parse($order->created_at)->diffForHumans()); ?></span></li> 
                                                <li class="list-group-item d-flex justify-content-between align-items-center darker">الكمية المطلوبة<span class="badge badge-warning">0.5 BTC</span></li> 
                                                <li class="list-group-item d-flex justify-content-between align-items-center darker">حالة الطلب<span class="badge badge-warning">لم يكتمل</span></li> 
                                            <li class="list-group-item d-flex justify-content-between align-items-center darker">تنبيهات<span class="badge badge-warning">0</span></li> 
                                        </ul> 
                                        <div class="card-body buttons-center">
                                            <a href="<?php echo e(route('user.myorders.show', $order->id)); ?>" class="btn btn-success btn-sm">متابعة الطلب</a> 
                                            <button type="button" class="btn btn-danger btn-sm">حذف الطلب</button>
                                        </div>
                                    </div>
                                </div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
      


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>