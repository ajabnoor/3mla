<?php $__env->startComponent('mail::message'); ?>
# مرحبا بك <?php echo e($product->user->name); ?>

لقد قام العضو <?php echo e($user->name); ?> بإنشاء طلب جديد على منتجك الخاص بعملة ال<?php echo e($product->currency->name); ?> <br>
لمتابعة الطلب قم بزيارة هذا الرابط<br>
<?php echo e($url); ?>



شكرا لك<br>
موقع <?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
