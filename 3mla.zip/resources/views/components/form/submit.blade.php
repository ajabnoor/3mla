    
{{ Form::submit($value,['class' => 'btn btn-primary'], $attributes) }}
