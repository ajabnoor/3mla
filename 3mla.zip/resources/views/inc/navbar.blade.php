
       <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <a href="{{ route('home') }}"><img src="{{ asset('img/logo.png') }}" alt="" style="height:50px;margin-left:10px"></a>

          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
              <li class="nav-item active">
                <a class="nav-link" href="{{ route('home') }}">الرئيسية <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="{{ route('user.myorders.index') }}">طلباتي
                    @if ($buyer_notifications>0)
                    <span class="badge badge-danger" >{{$buyer_notifications}}</span>
                @endif
                </a>
                  
              </li>
              <li class="nav-item">
                  <a class="nav-link" href="{{ route('user.mycustomers.index') }}">طلبات العملاء
                      @if ($owner_notifications>0)
                      <span class="badge badge-danger">{{$owner_notifications}}</span>
                  @endif
                </a>
                </li>
              <li class="nav-item">
                <a class="nav-link" href="{{ route('user.mysales.index') }}">مبيعاتي
              </a>
              </li>
              
              @role('admin')
              <li class="nav-item">
                  <a class="nav-link" href="{{ route('admin.home') }}">لوحة الأدمين</a>
                </li>
                @endrole

                <li class="nav-item">
                    <a class="nav-link" href="https://twitter.com/3mla_net"> تويتر <img src="{{ asset('img/twitter.ico') }}" alt="" style="height:15px"></a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link" href="https://t.me/www_3mla_net"> تيليجرام <img src="{{ asset('img/telegram.png') }}" alt="" style="height:12px"></a>
                    </li>
                  
                  
              {{-- <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Dropdown link
                  </a>
                  <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <a class="dropdown-item" href="#">Action</a>
                    <a class="dropdown-item" href="#">Another action</a>
                    <a class="dropdown-item" href="#">Something else here</a>
                  </div>
                </li> --}}
            </ul>
          </div>
          @if (Route::has('login'))
      
          @auth
          <a class="btn btn-outline-secondary droid" href="{{ route('logout') }}">تسجيل الخروج</a>
          @else
          <a class="btn btn-outline-secondary droid" href="{{ route('register') }}">تسجيل جديد</a>
          <a class="btn btn-outline-secondary droid btn-extra-margin" href="{{ route('login') }}">تسجيل دخول</a>
          @endauth
      
    @endif
        </nav>
        