<footer class="pt-4 my-md-5 pt-md-5 border-top">
        <div class="row">
          <div class="col-3 col-md">
            <img  src="{{ asset('img/logo.png') }}" alt=""  height="35">
          </div>
          
          <div class="col-6 col-md">
          موقع عملة 
            © 2017-2018
          </div>
          
          <div class="col-3 col-md">
         <a href="https://twitter.com/3mla_net"><img src="{{ asset('img/twitter.ico') }}" alt="" style="height:25px;float:left;margin-right:10px"></a> 
        <a href="https://t.me/www_3mla_net"><img src="{{ asset('img/telegram.png') }}" alt="" style="height:20px;float:left"></a>
          </div>
        </div>
      </footer>