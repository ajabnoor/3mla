<template>
        
        <div class="row">
            <div class="col-sm-4" v-for="product in products" v-bind:key="product.id">
                <div class="card mb-4 box-shadow card-red" v-if="product.type === 'sell'">
                    <img class="card-img-top" :src="product.currency.logo" :alt="product.currency.name">
                    <div class="card-body padding-top-zero">
                        <h5 class="card-title sell-red">{{product.currency.name}} للبيع بسعر</h5>
                        <h1 class="card-title pricing-card-title title-center">{{product.price}} {{product.price_currency.name}}<small class="text-muted">/ {{product.currency.code}}</small></h1>
                    </div>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item d-flex justify-content-between align-items-center list-coin">اسم العضو<span class="badge badge-info">{{product.user.name}}</span></li> 
                        <li class="list-group-item d-flex justify-content-between align-items-center list-coin">المكان<span class="badge badge-secondary">{{product.country.name}} - {{product.city.name}}</span></li>
                        <li class="list-group-item d-flex justify-content-between align-items-center list-coin">عمليات سابقة<span class="badge badge-secondary">{{product.user.finished_orders.length}}</span></li>
                        <li class="list-group-item d-flex justify-content-between align-items-center list-coin">سرعة التحويل<span class="badge badge-secondary">{{product.speed}}</span></li>
                        <li class="list-group-item d-flex justify-content-between align-items-center list-coin">طرق التحويل<span class="badge badge-secondary">{{product.transfer_methods}}</span></li>
                        <li class="list-group-item d-flex justify-content-between align-items-center list-coin">الكمية المتوفرة<span class="badge badge-secondary">{{product.available}} {{product.currency.code}}</span></li>
                        <li class="list-group-item d-flex justify-content-between align-items-center list-coin">أقل كمية للبيع<span class="badge badge-secondary">{{product.min_amount}}</span></li>
                        <li class="list-group-item d-flex justify-content-between align-items-center list-coin">التقييم<span class="badge badge-gold">بائع معتمد</span></li>
                    </ul>
                    <div class="card-body buttons-center">
                        
                  
                    <a :href="'user/neworder/'+product.id"  class="btn btn-success btn-sm">اطلب الأن</a>
                    <a :href="'user/neworder/'+product.id" class="btn btn-warning btn-sm">تواصل مع البائع</a>
                    </div>
                </div>

                <div class="card mb-4 box-shadow card-green" v-else>
                    <img class="card-img-top" :src="product.currency.logo" :alt="product.currency.name">
                    <div class="card-body padding-top-zero">
                        <h5 class="card-title sell-green">طلب {{product.currency.name}} بسعر</h5>
                        <h1 class="card-title pricing-card-title title-center">{{product.price}} {{product.price_currency.name}}<small class="text-muted">/ {{product.currency.code}}</small></h1>
                    </div>
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item d-flex justify-content-between align-items-center list-coin">اسم العضو<span class="badge badge-info">{{product.user.name}}</span></li> 
                        <li class="list-group-item d-flex justify-content-between align-items-center list-coin">المكان<span class="badge badge-secondary">{{product.country.name}} - {{product.city.name}}</span></li>
                        <li class="list-group-item d-flex justify-content-between align-items-center list-coin">عمليات سابقة<span class="badge badge-secondary">{{product.user.finished_orders.length}}</span></li>
                        <li class="list-group-item d-flex justify-content-between align-items-center list-coin">سرعة التحويل<span class="badge badge-secondary">{{product.speed}}</span></li>
                        <li class="list-group-item d-flex justify-content-between align-items-center list-coin">طرق التحويل<span class="badge badge-secondary">{{product.transfer_methods}}</span></li>
                        <li class="list-group-item d-flex justify-content-between align-items-center list-coin">الكمية المتوفرة<span class="badge badge-secondary">{{product.available}} {{product.currency.code}}</span></li>
                        <li class="list-group-item d-flex justify-content-between align-items-center list-coin">أقل كمية للشراء<span class="badge badge-secondary">{{product.min_amount}}</span></li>
                        <li class="list-group-item d-flex justify-content-between align-items-center list-coin">التقييم<span class="badge badge-gold">بائع معتمد</span></li>
                    </ul>
                    <div class="card-body buttons-center">
                    <a :href="'user/neworder/'+product.id" class="btn btn-success btn-sm">اطلب الأن</a>
                    <a :href="'user/neworder/'+product.id" class="btn btn-warning btn-sm">تواصل مع المشتري</a>
                    </div>
                </div>
            </div>
        </div>

</template>

<script>
    export default {
        props: ['products'],
        data(){
            return{
                
            }
        },
        created(){
            
        },
        methods: {
            
        }
    }
</script>

